package com.pagosoft.expression;

class CharExpression extends Expression {
	private char ch;

	public CharExpression(char ch) {
		this.ch = ch;
	}

	public boolean accept(CharInput in) {
		if(in.LA(1) == ch) {
			in.consume();
			return true;
		}
		return false;
	}

	public String toString() { return String.valueOf(ch); }
}
